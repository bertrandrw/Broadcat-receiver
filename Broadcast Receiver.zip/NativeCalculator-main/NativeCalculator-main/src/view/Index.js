// index.js
import { AppRegistry } from 'react-native';
import { name as appName } from './app.json';
import App from './App';
import { firebaseConfig } from './config'; // Your Firebase config file
import { getFirebaseApp } from '@react-native-firebase/app';

if (!getFirebaseApp()) {
  initializeApp(firebaseConfig);
}

AppRegistry.registerComponent(appName, () => App);
